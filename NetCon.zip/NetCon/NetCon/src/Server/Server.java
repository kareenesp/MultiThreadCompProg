/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.net.ssl.SSLServerSocket;

/**
 *
 * @author BlackMoon
 */
public final class Server {
    
    private Server() {
        Clients = new HashMap<>();
        port = 3310; //Default port
        Messages = "";
        this.addNewMessage("Server was launched");
    }
    
    private Boolean serverStarted = false;
    private HashMap<Integer, Handler> Clients;
    private String Messages;
    private String ClientMessages = "NETCOM V1\n\n=================";
    private Socket socket;
    private ServerSocket server_socket;
    private Integer port;
    
    private static class server_instance {
        
        private static final Server INSTANCE = new Server();
    }
    
    public static Server getInstance() {
        return server_instance.INSTANCE;
    }
    
    public void ConfigServer(Integer Port) {
        port = Port;
    }
    
    public String getMessages() {
        return this.Messages;
    }
    
    public void addNewMessage(String str) {
        Messages += "\n" + str;
    }
    
    public String client_getMessages() {
        return this.ClientMessages;
    }
    
    public void client_addNewMessage(String str) {
        ClientMessages += "\n" + str;
    }
    
    public HashMap<Integer, Handler> getClients() {
        return Clients;
    }
    
    public void addNewClient(Integer UserID, Handler client) {
        Clients.put(UserID, client);
    }
    
    public Boolean startServer() {
        try {
            server_socket = new ServerSocket(port);
            this.addNewMessage("Started Connection to port: " + port);
            serverStarted = true;
            return true;
        } catch (Exception e) {
            this.addNewMessage("Error catched:  " + e.getMessage());
        }
        return false;
    }
    
    public Thread runServer() {
        return new Thread(() -> {
            while (true) {
                
                try {
                    //if new client enters the server

                    socket = server_socket.accept();
                    this.addNewMessage("\nNew Client joined the server: " + socket.getInetAddress());
                    
                    DataInputStream dis = new DataInputStream(socket.getInputStream());
                    DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
                    
                    Handler client = new Handler(socket, dis, dos);

                    //adding to thread pool
                    Thread th = new Thread(client);
                    th.start();
                    
                } catch (IOException ex) {
                    
                    this.addNewMessage("Error catched:  " + ex.getMessage());
                }
            }
        });
    }
}
