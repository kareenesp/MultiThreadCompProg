/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Server;

import Server.Response.PATH;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author BlackMoon
 */
public class Handler implements Runnable {

    final DataInputStream dis;
    final DataOutputStream dos;
    Socket s;
    boolean isUserLoggedIn;
    String UNAME;
    Integer UID;

    public Handler(Socket s, DataInputStream dis, DataOutputStream dos) {
        this.dis = dis;
        this.dos = dos;
        this.s = s;
        this.isUserLoggedIn = false;
    }

    @Override
    public void run() {
        String received;
        while (true) {
            try {

                received = dis.readUTF();

                String command = received.split("#")[0];
                String message = received.split("#")[1];

                StringTokenizer st = new StringTokenizer(message, ",");
                UID = Integer.parseInt(st.nextToken());
                UNAME = st.nextToken();
                String u_message = st.nextToken();

                if (command.equals("logout")) {
                    Response.emit(PATH.SERVER, "\nDisconneting " + this.UID + " [ " + this.UNAME + " ]");
                    if (Server.getInstance().getClients().containsKey(UID)) {
                        this.isUserLoggedIn = false;
                        Server.getInstance().getClients().remove(UID); //removing to client list
                        String sm = "\nClient  " + this.UID + " [ " + this.UNAME + " ] was properly disconnected";
                        Response.emit(PATH.SERVER, sm);
                        Response.emit(PATH.GROUP, sm);
                        break; //breaking loop
                    }
                }

                if (command.equals("login")) {
                    Server.getInstance().addNewMessage("\nLogging in " + this.UID + " [ " + this.UNAME + " ]");
                    this.isUserLoggedIn = true;
                    if (Server.getInstance().getClients().containsKey(UID)) {
                        this.isUserLoggedIn = false;
                        String cm = "\nUnable to enter this server, due of this UID was already connected to the server. please check your credentials"; //constructed message
                        this.dos.writeUTF(cm);
                        break; //breaking loop
                    }

                    String cm = "\nWelcome! " + this.UNAME + ", ID: " + this.UID; //constructed message
                    //this.dos.writeUTF(cm);
                    Response.emit(PATH.GROUP, cm);

                    Server.getInstance().addNewClient(UID, this);
                    Response.emit(PATH.SERVER, "Client " + this.UNAME + " was added to active members");
                }

                if (command.equals("refreshMessages")) {
                    HashMap<Integer, Handler> clients = Server.getInstance().getClients();
                    if (clients.containsKey(UID)) {
                        Handler client = clients.get(UID);
                        try {
                            Response.emit(PATH.CLIENT, Server.getInstance().client_getMessages(), client.dos);
                        } catch (IOException ex) {
                            Response.emit(PATH.SERVER, "\n" + ex.getMessage());
                        }
                    } else {
                        this.isUserLoggedIn = false;
                        this.s.close();
                        break; //breaking loop
                    }
                }

                if (command.equals("getClients")) {
                    HashMap<Integer, Handler> clients = Server.getInstance().getClients();
                    if (clients.containsKey(UID)) {
                        Handler client = clients.get(UID);
                        try {
                            List<String> ls = new ArrayList<>();
                            clients.forEach((i, f) -> {
                                ls.add(f.UNAME);
                            });
                            Response.emit(PATH.CLIENT, ls.toString(), client.dos);
                        } catch (IOException ex) {
                            Response.emit(PATH.SERVER, "\n" + ex.getMessage());
                        }
                    } else {
                        this.isUserLoggedIn = false;
                        this.s.close();
                        break; //breaking loop
                    }
                }

                if (command.equals("send")) {
                    HashMap<Integer, Handler> clients = Server.getInstance().getClients();
                    if (clients.containsKey(UID)) {
                        Handler client = clients.get(UID);
                        if (client.isUserLoggedIn) {
                            String cm = "\n" + client.UNAME + ": " + u_message; //constructed message
                            //client.dos.writeUTF(cm);
                            Response.emit(PATH.GROUP, cm);
                            Response.emit(PATH.SERVER, cm);
                        }
                    } else {
                        this.isUserLoggedIn = false;
                        this.s.close();
                        break; //breaking loop
                    }
                }
            } catch (SocketException e) {
                if (e.toString().contains("Socket closed") || e.toString().contains("Connection reset")
                        || e.toString().contains("Broken pipe")) {
                    Server.getInstance().getClients().remove(UID); //removing to client list
                    break;
                }
            } catch (IOException e) {
                Response.emit(PATH.SERVER, "\n" + e.getMessage());
            }
        }

        try {
            //Cleaning
            this.dis.close();
            this.dos.close();
        } catch (IOException e) {
            Response.emit(PATH.SERVER, "\n" + e.getMessage());
        }
    }
}
